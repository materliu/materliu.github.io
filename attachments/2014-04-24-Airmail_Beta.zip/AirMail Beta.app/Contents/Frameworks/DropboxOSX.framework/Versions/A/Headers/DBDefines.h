//
//  DBDefines.h
//  DropboxSDK
//
//  Created by Brian Smith on 8/8/11.
//  Copyright 2011 Dropbox, Inc. All rights reserved.
//

// Taken from three20 (http://three20.info/)
#define DB_FIX_CATEGORY_BUG(name) @interface DB_FIX_CATEGORY_BUG##name @end @implementation DB_FIX_CATEGORY_BUG##name @end
