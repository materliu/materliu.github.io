//
//  MCAsyncSMTP.h
//  mailcore2
//
//  Created by DINH Viêt Hoà on 1/11/13.
//  Copyright (c) 2013 MailCore. All rights reserved.
//

#ifndef __MAILCORE_MCASYNCSMTP_H_

#define __MAILCORE_MCASYNCSMTP_H_

#include <MailCore/MCSMTPAsyncSession.h>
#include <MailCore/MCSMTPOperation.h>
#include <MailCore/MCSMTPOperationCallback.h>

#endif
