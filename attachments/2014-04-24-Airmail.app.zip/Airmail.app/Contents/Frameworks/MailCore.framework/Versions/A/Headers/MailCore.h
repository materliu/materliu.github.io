//
//  mailcore.h
//  mailcore2
//
//  Created by DINH Viêt Hoà on 1/10/13.
//  Copyright (c) 2013 MailCore. All rights reserved.
//

#ifndef __MAILCORE_MAILCORE_h

#define __MAILCORE_MAILCORE_h

#include <MailCore/MCCore.h>
#include <MailCore/MCAsync.h>
#include <MailCore/MCObjC.h>

#import "AMProxy.h"
#endif
