#ifndef __MAILCORE_MCHASH_H_

#define __MAILCORE_MCHASH_H_

#ifdef __cplusplus

namespace mailcore {

    unsigned int hashCompute(const char * key, unsigned int len);

}

#endif

#endif
