//
//  AMProxy.h
//  mailcore2
//
//  Created by Joe on 29/08/13.
//  Copyright (c) 2013 MailCore. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AMProxy : NSObject
{
    
}
+ (AMProxy*) shared;

- (NSString*) messageId;
- (void) setTempString:(NSString*)tmp;

-(void) MailCoreXEnableLogging;
-(void) MailCoreXDisableLogging;
@end
