#ifndef __MAILCORE_MCSMTP_H

#define __MAILCORE_MCSMTP_H

#include <MailCore/MCSMTPProgressCallback.h>
#include <MailCore/MCSMTPSession.h>

#endif
